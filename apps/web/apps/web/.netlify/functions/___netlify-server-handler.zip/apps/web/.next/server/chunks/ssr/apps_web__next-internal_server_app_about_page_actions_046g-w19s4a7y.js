module.exports=[38960,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_about_page_actions_046g-w19s4a7y.js.map