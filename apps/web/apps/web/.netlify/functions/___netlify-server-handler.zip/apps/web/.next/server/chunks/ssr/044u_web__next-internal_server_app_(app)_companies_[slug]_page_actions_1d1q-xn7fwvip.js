module.exports=[74124,a=>{"use strict";a.s([])}];

//# sourceMappingURL=044u_web__next-internal_server_app_%28app%29_companies_%5Bslug%5D_page_actions_1d1q-xn7fwvip.js.map