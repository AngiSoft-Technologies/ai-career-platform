module.exports=[18788,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_%28app%29_matches_page_actions_1mt3aj3gx4u23.js.map