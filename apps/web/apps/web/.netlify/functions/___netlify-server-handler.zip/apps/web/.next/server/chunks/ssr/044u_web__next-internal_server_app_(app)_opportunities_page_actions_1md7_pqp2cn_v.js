module.exports=[20473,a=>{"use strict";a.s([])}];

//# sourceMappingURL=044u_web__next-internal_server_app_%28app%29_opportunities_page_actions_1md7_pqp2cn_v.js.map