globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/QasgZrZNXIM5LQ6VV6-Mp/_buildManifest.js",
    "static/QasgZrZNXIM5LQ6VV6-Mp/_ssgManifest.js",
    "static/QasgZrZNXIM5LQ6VV6-Mp/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1x6obpmlu1_c2.js",
    "static/chunks/2kzd2bib-2ux6.js",
    "static/chunks/0d2izxpag9jzc.js",
    "static/chunks/15tq6lfr9fszd.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/admin/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/applications/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/applications/[id]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/automation/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/companies/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/companies/[slug]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/connections/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/dashboard/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/documents/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/documents/[id]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/followups/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/matches/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/moderation/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/opportunities/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/opportunities/[id]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/profile/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/settings/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/sources/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/support/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/about/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/download/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/faq/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/features/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/login/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/pricing/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/privacy/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/security/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/stories/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/terms/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2kzd2bib-2ux6.js",
        "static/chunks/0d2izxpag9jzc.js",
        "static/chunks/15tq6lfr9fszd.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
