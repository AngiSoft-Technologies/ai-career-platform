module.exports=[37087,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_terms_page_actions_0zkd_cexafzkf.js.map