module.exports=[32992,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_%28app%29_applications_page_actions_0cityavr59k72.js.map