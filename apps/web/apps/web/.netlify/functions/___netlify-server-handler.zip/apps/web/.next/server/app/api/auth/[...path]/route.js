var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...path]/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__1dgnx8um15yib._.js")
R.c("server/chunks/044u_web__next-internal_server_app_api_auth_[___path]_route_actions_1ssl06sx9dd5m.js")
R.m(40853)
module.exports=R.m(40853).exports
