module.exports=[63132,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_%28app%29_profile_page_actions_0s7up3gk65dp1.js.map