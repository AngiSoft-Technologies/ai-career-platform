module.exports=[1250,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_%28app%29_connections_page_actions_12ul6xnsrl9wa.js.map