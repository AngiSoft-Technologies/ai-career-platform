module.exports=[64795,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_%28app%29_settings_page_actions_1zs-bcu_bk09w.js.map