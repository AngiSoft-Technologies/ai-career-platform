module.exports=[39808,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_privacy_page_actions_0qqzm3j-strs1.js.map