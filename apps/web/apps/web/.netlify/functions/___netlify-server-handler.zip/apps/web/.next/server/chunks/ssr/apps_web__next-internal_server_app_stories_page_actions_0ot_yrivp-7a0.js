module.exports=[58702,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_stories_page_actions_0ot_yrivp-7a0.js.map