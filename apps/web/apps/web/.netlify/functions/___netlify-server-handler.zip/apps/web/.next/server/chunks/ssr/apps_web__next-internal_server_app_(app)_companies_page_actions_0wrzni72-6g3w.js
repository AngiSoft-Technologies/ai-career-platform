module.exports=[37510,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_%28app%29_companies_page_actions_0wrzni72-6g3w.js.map