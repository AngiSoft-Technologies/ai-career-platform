module.exports=[40277,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_%28app%29_sources_page_actions_0p09-4lb9y-8s.js.map