module.exports=[51324,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_%28app%29_moderation_page_actions_0mbdje5h9orw6.js.map