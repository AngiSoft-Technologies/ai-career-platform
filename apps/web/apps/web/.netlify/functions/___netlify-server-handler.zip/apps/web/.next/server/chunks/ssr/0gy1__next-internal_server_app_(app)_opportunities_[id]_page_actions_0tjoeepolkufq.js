module.exports=[94736,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0gy1__next-internal_server_app_%28app%29_opportunities_%5Bid%5D_page_actions_0tjoeepolkufq.js.map