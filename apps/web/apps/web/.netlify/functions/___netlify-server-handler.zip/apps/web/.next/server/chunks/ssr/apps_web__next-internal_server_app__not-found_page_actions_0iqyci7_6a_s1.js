module.exports=[27559,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app__not-found_page_actions_0iqyci7_6a_s1.js.map