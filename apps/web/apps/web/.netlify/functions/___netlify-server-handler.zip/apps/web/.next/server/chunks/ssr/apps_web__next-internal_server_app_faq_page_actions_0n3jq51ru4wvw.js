module.exports=[9762,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_web__next-internal_server_app_faq_page_actions_0n3jq51ru4wvw.js.map